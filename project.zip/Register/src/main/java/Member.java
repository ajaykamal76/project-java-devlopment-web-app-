
public class Member {
	private String Email,Password;

	public Member( String Email, String Password) {
		super();
		
		this.Email = Email;
		this.Password = Password;
		
	}

	public Member() {
		super();
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String Email) {
		this.Email = Email;
	}

	public String getPassword() {
		return Password;
	}

	public void setPassword(String Password) {
		this.Password = Password;
	}

	





}
