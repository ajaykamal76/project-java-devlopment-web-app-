import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Servlet implementation class Register
 */
@WebServlet("/Register")
public class Register extends HttpServlet {
    private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public Register() {
        super();
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.getWriter().append("Served at: ").append(request.getContextPath());
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = request.getParameter("Email");
        String password = request.getParameter("Password");

        if (email == null || password == null || email.isEmpty() || password.isEmpty()) {
            response.getWriter().print("Email and Password must not be empty");
            return;
        }

        Member member = new Member(email, password);

        RegisterDao rDao = new RegisterDao();
        String result = rDao.insert(member);

        response.getWriter().println(result);
        response.getWriter().println("Your email ID is:");
        response.getWriter().println(email);
        response.getWriter().println("YOUR password is:");
        response.getWriter().println(password);
    }
}
