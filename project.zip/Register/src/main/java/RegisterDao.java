import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class RegisterDao {
    private String dburl = "jdbc:mysql://localhost:3306/userdb";
    private String dbuname = "root";
    private String dbpassword = "root";
    private String dbdriver = "com.mysql.cj.jdbc.Driver";
 
    public Connection getConnection() {
        Connection con = null;
        try {
            Class.forName(dbdriver); // Register MySQL JDBC driver
            con = DriverManager.getConnection(dburl, dbuname, dbpassword);
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
        return con;
    }

    public String insert(Member member) {
        Connection con = getConnection();
        String result = "Username & Password created Successfully";
 
        
        String sql = "INSERT INTO member (Email,Password) VALUES (?, ? )";

        try {
            PreparedStatement ps = con.prepareStatement(sql);
            
            ps.setString(1, member.getEmail());
            ps.setString(2, member.getPassword());
            
          

            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            result = "Data is not entered";
        } finally {
            // Close the connection in finally block to ensure it always gets closed
            if (con != null) {
                try {
                    con.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }

        return result;
    }
}
